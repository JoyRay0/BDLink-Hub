<!DOCTYPE html>
<html>
<head>
    <title>Email Verification</title>
</head>
<body>
    <h2>ভেরিফিকেশন কোড</h2>
    <p>আপনার কোড হলো: <strong>{{ $code }}</strong></p>
    <p>কেউর সাথে শেয়ার করবেন না।</p>
</body>
</html>

